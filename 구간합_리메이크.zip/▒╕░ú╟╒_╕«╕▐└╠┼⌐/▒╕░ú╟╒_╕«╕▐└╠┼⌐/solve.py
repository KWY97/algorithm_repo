import sys
sys.stdin = open('input.txt', 'r')

def arr_len(arr):
    global arr_max
    for i in range(N):
        if arr_max < len(arr[i]):
            arr_max = len(arr[i])
    return arr_max

T = int(input())
for tc in range(1, T+1):
    N, M = map(int, input().split())
    arr = [list(map(int, input().split())) for _ in range(N)]
    arr_max = float('-inf')
    col = arr_len(arr)

    for i in range(N):
        for j in range(col):
            try:
                arr[i][j]
            except:
                arr[i].append(0)

    # 처음 나온 0이 있으면 위치 교환
    for i in range(col):
        for j in range(N):
            if arr[j][i] == 0:


